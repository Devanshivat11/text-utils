import React from 'react'

function About() {
    return (
        <div className="container">
            <h1 className="my-3">What Makes a Great About Us Page?</h1>
            Your About Us page should be:

            Informative. It doesn’t always have to tell your whole story, but it should at least provide people with an idea of .
            Contain social proof, testimonials, and some personal information that visitors can relate to, such as education, family, etc.
            Useful.
            Engaging.
            Easy to navigate.
            Accessible on any device.
            Does that all sound complicated?
        </div>
    )
}

export default About;
